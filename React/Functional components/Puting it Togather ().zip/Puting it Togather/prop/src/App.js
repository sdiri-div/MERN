import logo from './logo.svg';
import './App.css';
import FunctionCom from './components/FunctionCom';
function App() {
  
  return (
   
    
    <div className="App">
   
   <FunctionCom 
   LestName={"Doe"}
   FirstName={"Jane"}
   age={45}
   hair={"Black"}
   />
   <FunctionCom
   LestName={"Smith"}
   FirstName={" John"}
   age={88}
   hair={"Brown"}
   />
    </div>
    
  );
}

export default App;
