import React from 'react'

const FunctionCom = () => {
  return (
    <fieldset>

      <h1>Hello Dojo!</h1>
      <h2>Things I need to do:</h2>
      <ul>
        <li>Learn React </li>
        <li>Climb Mt Everest</li>
        <li>Run a marathon</li>
        <li>Feed the dogs</li>
      </ul>
      
    <legend>FunctionCom</legend>
    </fieldset>
  )
}

export default FunctionCom