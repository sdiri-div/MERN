import logo from './logo.svg';
import './App.css';
import FunctionCom from './components/FunctionCom';
function App() {
  return (
    <fieldset>
    <div className="App">
      <legend>
      <FunctionCom/>
      </legend>
    </div>
    
    </fieldset>
  );
}

export default App;
