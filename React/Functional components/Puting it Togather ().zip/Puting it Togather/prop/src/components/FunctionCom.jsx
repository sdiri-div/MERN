import React, { useState } from 'react'

const FunctionCom = (props) => {
const [inStock, setInstock] = useState(props.age);


  return (
    <fieldset>
      <h1>{props.LestName}, {props.FirstName}</h1>
    <h3>Age:
       {inStock} </h3>
    <h3> hair Color: {props.hair}</h3>
   
    
    <button onClick={(event) =>setInstock(inStock +1)}>Birthday button for {props.FirstName} {props.LestName}</button>

    </fieldset>
  )
}

export default FunctionCom