import logo from "./logo.svg";
import './App.css';
import axios from 'axios';
import React,{useEffect, useState} from 'react'

const  App = props => {
  // We expect an array of pokemon objects back and so we will
  //    choose an empty array as the initial value to be held
  //    in state
  const [responseData, setResponseData] = useState([]);

  // this will run immediately after the JSX is rendered
  useEffect(() => {
    axios.get('https://pokeapi.co/api/v2/pokemon?limit=807')
      .then(response => {
        // this will return the data from the response object
        //    in a json format
        console.log(response.data.results);
        setResponseData(response.data.results);
      })
      .catch((err)=> console.log(err));
  }, []);  
  return (
    <div className="App" style={{ width: "200px", margin: "auto" }}>
    <h1>Axios Pokemon API Assignment</h1>
    <ull>
      {responseData.map((pokemon, index) =>(
      <li key={index}>{pokemon.name}</li>
    ))}
    </ull>
    </div>
  );
}
export default App