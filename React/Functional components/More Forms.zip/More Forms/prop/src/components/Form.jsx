import React, { useState } from 'react'

const Form = () => {

    const [input, setInput] = useState("")
    const [name, setName]= useState("")
    const submitHandler = (event) =>{
        event.preventDefault()
    }


  return (
   <fieldset>
   <legend>form.js</legend>
   {JSON.stringify(input)}
   {JSON.stringify(name)}
   <form onSubmit={submitHandler}>
    <label> mohamed</label>
    <input type="text" onChange={(e) => {setInput (e.target.value)}}/>
    <input type="text" onChange={(e) => {setName (e.target.value)}}/>

   </form>
   
    
   <div>Form</div> 
   </fieldset>
  )
}

export default Form