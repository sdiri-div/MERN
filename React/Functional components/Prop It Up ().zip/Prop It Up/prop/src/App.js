import logo from './logo.svg';
import './App.css';
import FunctionCom from './components/FunctionCom';
function App() {
  
  return (
   <fieldset>
    
    <div className="App">
    <FunctionCom
        lastName={"Doe"}
        firstName={"Jane"}
        age={45}
        hairColor={"Hair Color: Black"}
      />
      <FunctionCom
        lastName={"smith"}
        firstName={"John"}
        age={88}
        hairColor={"Hair Color:Brown"}
      />
      <FunctionCom
       lastName={"Filmore"} 
       firstName={"Millard"} age={50} hairColor={"Hair Color:Brown"} />
      <FunctionCom
        lastName={"Smith"}
        firstName={"Maria"}
        age={62}
        hairColor={"Hair Color: Brown"}
      />
     
    </div>
    </fieldset>
  );
}

export default App;
