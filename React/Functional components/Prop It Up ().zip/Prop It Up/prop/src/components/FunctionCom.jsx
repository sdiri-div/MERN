import React from 'react'

const FunctionCom = (props) => {
    const {firstName,lastName,age, hairColor}=props;
  return (
    
    <fieldset>

    <h1>{lastName}, {firstName}</h1>
  
    
    <p>{age}</p>
    <p>{hairColor}</p>
    </fieldset>
  )
}

export default FunctionCom